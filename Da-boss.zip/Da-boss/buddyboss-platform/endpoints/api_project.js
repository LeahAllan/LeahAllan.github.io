define({
  "name": "BuddyBoss Platform",
  "version": "1.0.0",
  "description": "API Reference",
  "title": "BuddyBoss Platform",
  "url": "https://www.buddyboss.com/resources/api/",
  "template": {
    "withCompare": true,
    "withGenerator": true
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-05-17T05:59:54.807Z",
    "url": "http://apidocjs.com",
    "version": "0.22.0"
  }
});
