#	wp bp member

Manage BuddyBoss Member.

## EXAMPLE

    $ wp bp member generate --count=50
