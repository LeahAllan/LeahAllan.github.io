#	wp bp member generate

Generate BuddyPress members. See documentation for `wp_user_generate`.

## OPTIONS

[--count=&lt;number&gt;]
: How many members to generate.
\---
default: 100
\---

## EXAMPLE

    $ wp bp member generate --count=50
