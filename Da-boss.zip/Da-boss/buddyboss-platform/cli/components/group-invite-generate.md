#	wp bp group invite generate

Generate random group invitations.

## OPTIONS

[--count=&lt;number&gt;]
: How many groups invitations to generate.
\---
default: 100
\---

## EXAMPLE

    $ wp bp group invite generate --count=50
