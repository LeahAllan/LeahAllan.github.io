# wp bp activity ham

Ham an activity.

## OPTIONS

&lt;activity-id&gt;
: Identifier for the activity.

## EXAMPLES

	$ wp bp activity ham 500
	Success: Activity marked as ham.
	
	$ wp bp activity unspam 4679
	Success: Activity marked as ham.
	
	
