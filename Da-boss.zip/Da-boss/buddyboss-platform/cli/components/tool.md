#	wp bp tool

Manage Tool.

## Example

	$ wp bp tool repair friend-count
    
    $ wp bp tool fix friend-count
    Success: Counting the number of connections for each user. Complete!
