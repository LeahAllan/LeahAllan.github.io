#	wp bp tool repair

Repair.

## OPTIONS

&lt;type&gt;
: Name of the repair tool.
\---
options:
  - friend-count
  - group-count
  - blog-records
  - count-members
  - last-activity
\---

## EXAMPLES

    $ wp bp tool repair friend-count
    
    $ wp bp tool fix friend-count
    Success: Counting the number of connections for each user. Complete!
